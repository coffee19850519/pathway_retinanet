# Copyright (c) Open-MMLab. All rights reserved.

__version__ = '0.5.0'
short_version = __version__
