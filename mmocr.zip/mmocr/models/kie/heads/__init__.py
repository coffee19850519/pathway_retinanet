# Copyright (c) OpenMMLab. All rights reserved.
from .sdmgr_head import SDMGRHead

__all__ = ['SDMGRHead']
