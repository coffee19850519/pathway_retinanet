# Copyright (c) OpenMMLab. All rights reserved.
from .common import Maxpool2d

__all__ = ['Maxpool2d']
