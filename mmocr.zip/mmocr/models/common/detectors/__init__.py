# Copyright (c) OpenMMLab. All rights reserved.
from .single_stage import SingleStageDetector

__all__ = ['SingleStageDetector']
