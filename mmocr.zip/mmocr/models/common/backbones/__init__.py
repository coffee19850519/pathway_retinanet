# Copyright (c) OpenMMLab. All rights reserved.
from .unet import UNet

__all__ = ['UNet']
